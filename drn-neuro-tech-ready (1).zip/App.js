import React from 'react';

export default function App() {
  return (
    <div style={{backgroundColor: '#111', color: 'white', minHeight: '100vh', padding: '2rem', fontFamily: 'Arial, sans-serif'}}>
      <h1>DRN Neuro Tech</h1>
      <p>Where innovation meets the human mind — explore cutting-edge neurotechnology inventions.</p>
      <section>
        <h2>About the Company</h2>
        <p>DRN Neuro Tech is a pioneering company dedicated to the advancement of neurotechnology.</p>
      </section>
    </div>
  );
}