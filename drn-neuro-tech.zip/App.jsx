import React, { useState } from "react";
import { Mail, Instagram, Linkedin } from "lucide-react";

export default function DRNNeuroTech() {
  const [language, setLanguage] = useState("en");
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const content = {
    en: {
      heading: "DRN Neuro Tech",
      subtitle: "Where innovation meets the human mind — explore cutting-edge neurotechnology inventions.",
      aboutTitle: "About the Company",
      aboutText:
        "DRN Neuro Tech is a pioneering company dedicated to the advancement of neurotechnology. We specialize in transforming unique inventions into tangible products that push the boundaries of science, technology, and human potential. Our mission is to empower minds and enhance lives through intelligent innovation.",
      innovationsTitle: "Our Innovations",
      innovation1: {
        title: "Neural Sync Module",
        description:
          "A wearable device that enhances cognitive performance by synchronizing brainwave activity."
      },
      innovation2: {
        title: "Cortex Interface Pad",
        description:
          "A non-invasive neural interface that allows seamless interaction between the brain and digital systems."
      },
      contactTitle: "Contact Us",
      contactForm: {
        name: "Your Name",
        email: "Your Email",
        message: "Your Message",
        submit: "Send Message"
      },
      footer: "All rights reserved."
    },
    ar: {
      heading: "دي آر إن نيورو تك",
      subtitle: "حيث يلتقي الابتكار بالعقل البشري — استكشف أحدث تقنيات الأعصاب.",
      aboutTitle: "عن الشركة",
      aboutText:
        "دي آر إن نيورو تك هي شركة رائدة مكرسة لتطوير تقنيات الأعصاب. نحن متخصصون في تحويل الاختراعات الفريدة إلى منتجات ملموسة تدفع حدود العلم والتكنولوجيا والإمكانات البشرية. مهمتنا هي تمكين العقول وتحسين الحياة من خلال الابتكار الذكي.",
      innovationsTitle: "الابتكارات",
      innovation1: {
        title: "وحدة التزامن العصبي",
        description:
          "جهاز قابل للارتداء يعزز الأداء المعرفي من خلال تزامن نشاط الدماغ."
      },
      innovation2: {
        title: "وسادة واجهة القشرة الدماغية",
        description:
          "واجهة عصبية غير جراحية تسمح بتفاعل سلس بين الدماغ والأنظمة الرقمية."
      },
      contactTitle: "تواصل معنا",
      contactForm: {
        name: "اسمك",
        email: "بريدك الإلكتروني",
        message: "رسالتك",
        submit: "إرسال الرسالة"
      },
      footer: "جميع الحقوق محفوظة."
    }
  };

  const t = content[language];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Message submitted: " + JSON.stringify(form));
  };

  return (
    <main style={{ backgroundColor: "black", color: "white", padding: "2rem", fontFamily: "sans-serif" }}>
      <section style={{ maxWidth: "800px", margin: "auto" }}>
        <div style={{ textAlign: "right", marginBottom: "1rem" }}>
          <button onClick={() => setLanguage(language === "en" ? "ar" : "en")}>
            {language === "en" ? "العربية" : "English"}
          </button>
        </div>

        <header style={{ textAlign: "center", marginBottom: "3rem" }}>
          <h1 style={{ fontSize: "3rem", fontWeight: "bold" }}>{t.heading}</h1>
          <p style={{ color: "#ccc" }}>{t.subtitle}</p>
        </header>

        <section style={{ marginBottom: "2rem" }}>
          <h2>{t.aboutTitle}</h2>
          <p style={{ color: "#aaa" }}>{t.aboutText}</p>
        </section>

        <section style={{ marginBottom: "2rem" }}>
          <h2>{t.innovationsTitle}</h2>
          <div>
            <div style={{ marginBottom: "1rem", backgroundColor: "#111", padding: "1rem", borderRadius: "10px" }}>
              <h3>{t.innovation1.title}</h3>
              <p>{t.innovation1.description}</p>
            </div>
            <div style={{ backgroundColor: "#111", padding: "1rem", borderRadius: "10px" }}>
              <h3>{t.innovation2.title}</h3>
              <p>{t.innovation2.description}</p>
            </div>
          </div>
        </section>

        <section style={{ marginBottom: "2rem" }}>
          <h2>{t.contactTitle}</h2>
          <p><Mail size={16} /> contact@drnneurotech.com</p>
          <p><Instagram size={16} /> @drn.neuro.tech</p>
          <p><Linkedin size={16} /> DRN Neuro Tech</p>
          <form onSubmit={handleSubmit} style={{ marginTop: "1rem" }}>
            <input name="name" placeholder={t.contactForm.name} onChange={handleInputChange} style={{ width: "100%", padding: "0.5rem", marginBottom: "0.5rem" }} />
            <input name="email" placeholder={t.contactForm.email} onChange={handleInputChange} style={{ width: "100%", padding: "0.5rem", marginBottom: "0.5rem" }} />
            <textarea name="message" placeholder={t.contactForm.message} onChange={handleInputChange} style={{ width: "100%", padding: "0.5rem", marginBottom: "0.5rem" }} rows="4" />
            <button type="submit" style={{ width: "100%", padding: "0.5rem", backgroundColor: "#333", color: "white" }}>
              {t.contactForm.submit}
            </button>
          </form>
        </section>

        <footer style={{ textAlign: "center", color: "#666", marginTop: "3rem" }}>
          &copy; {new Date().getFullYear()} DRN Neuro Tech. {t.footer}
        </footer>
      </section>
    </main>
  );
}
